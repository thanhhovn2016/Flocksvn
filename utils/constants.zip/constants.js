// export const baseURL = 'http://localhost:8000/api/v1/';
//export const baseURL = 'http://54.203.235.172:8000/api/v1/';
// export const baseURL = 'http://5.189.148.68:8000/api/v1/';
// export const baseURL = 'http://vmi520323.contaboserver.net/api/v1/';
// export const baseURL = 'https://www.anarsupermarket.website/api/v1/';
// export const remoteBaseURL = 'https://www.anarsupermarket.website/api/v1/';

// export const baseURL = "https://shibainuii.com"
export const baseURL = 'https://api.flocks.vn/api/v1/';

export const dong = "đ"

const isOnline = true;
// export const mediaBaseURL = isOnline ? "https://shibainuii.com" : baseURL.replace("/api/v1/", "");
export const mediaBaseURL = isOnline ? "https://uploads.flocks.vn" : baseURL.replace("/api/v1/", "");
//export const mediaBaseURL = baseURL.replace("/api/v1/", "/");
// export const mediaBaseURL = "http://192.168.2.226:8000"

export const API_KEY = 'vaiDTsb0.S7XRhUacCPkyXaBGPt0vUA5QLddEBmn8';

// const frontendDomain = "https://flocks-website.vercel.app/";
// Change to vercel
const frontendDomain = "https://localhost:3000/";
export const nextJsBaseURL = `${frontendDomain}api/`;

export const googleRedirectUriEn = `${frontendDomain}en/social/google`;
export const googleRedirectUriVi = `${frontendDomain}social/google`;
export const facebookRedirectUriEn = `${frontendDomain}en/social/facebook`;
export const facebookRedirectUriVi = `${frontendDomain}social/facebook`;
export const appleRedirectUriEn = `${frontendDomain}en/social/apple`;
export const appleRedirectUriVi = `${frontendDomain}social/apple`;

export const apiRoutes = {
    signUpWithEmail: "auth/email/sign_up/",
    signInWithEmail: "auth/email/sing_in/",
    refreshToken: "auth/token/refresh/",
    generateSocialUrl: "auth/social/oauth_uri/",
    signInWithSocial: "auth/social/",
    verifyEmail: "auth/email/sign_up/verify/",
    resendVerifyEmail: "auth/email/sign_up/resend_verify/",
    userProfile: "auth/profile/me/",
    passwordResetCode: "auth/password/reset/email/send_code/",
    passwordResetConfirm: "auth/password/reset/email/confirm_code/",
    checkUserVerificationStatus: "verification/id/me",
    uploadVerificationId: "verification/id/",
    project:"project/",

    investmentQuestions: "investment/investment_info_question/",
    createInvestmentProfile: "investment/add_more_info/",
    investmentRelatedCompany:'investment/related_company',
    investmentStatistic:"/investment/statistic/",
    companyStatistic:"/company/statistic/",

    companyUserRelatedCompany:"/company/user_related_company/",
    companyUserAppliedProject:"/company/user_applied_company/",

    companyQuestions: "company/company_info_question/",
    createCompanyProfile: "company/add_more_info/",
    allCompanies: "company/",
    createProject: "company/company/presentation/create_presentation/",
    projectCategories: "company/company/presentation/company_category/",
    allProjects: "company/company/presentation/",
    trendProjects: "company/company/presentation/trend_company",
    hotProject: "company/company/presentation/hot_company",
    company:"company/company/presentation/",


    mediaUpload: "media/upload_media_file/",
    mediaMultiUpload: "media/upload_media_file/bulk_upload/",

    contactForm: "contact_form/",

    blogCategoriesWithPosts: "blog/category/",
    blogPostsWithCategory: "blog/category/overview_with_post/",
    singleBlog: "blog/",
    blog: "blog/",
    blogCategory: "blog/category/",

    allEvents: "event/",
    singleEvent: "event/",

    faq: "faq/",
    faqCategories: "faq/category/",
    faqCategoryItems: "faq/category/"
}

export const remoteApiRoutes = {
    signUpWithEmail: "auth/sign_up/email/",
    signInWithEmail: "auth/sign_in/email/",
    refreshToken: "auth/tokens/refresh/",
    generateSocialUrl: "auth/social/oauth_uri/",
    signInWithSocial: "auth/social/",
    verifyEmail: "auth/sign_up/email/verify/",
    resendVerifyEmail: "auth/sign_up/email/resend_varify/",
    userProfile: "auth/profile/me/",
    passwordResetCode: "auth/password/reset/email/send_code/",
    passwordResetConfirm: "auth/password/reset/email/",

    investmentQuestions: "investment/investment_info_question/",
    createInvestmentProfile: "investment/add_more_info/",

    companyQuestions: "company/company_info_question/",
    createCompanyProfile: "company/add_more_info/",

    mediaUpload: "media/upload_media_file/",

    contactForm: "contact_form/",


}

const nextjsApiRoutes = {
    signInWithEmail: "auth/login",
    refreshToken: "auth/refresh",
}